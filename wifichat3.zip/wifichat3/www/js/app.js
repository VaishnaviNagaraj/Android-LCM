// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic', 'firebase', 'ngCordova'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
 
    Parse.initialize("YOUR APP ID", "JAVASCRIPT KEY");
 
  });
})

.state('chat', {
  url: '/chat',
  templateUrl: 'templates/chat.html',
  controller: 'ChatCtrl'
})

.factory('Messages', function($firebaseArray) {
  var messagesRef = new Firebase("https://<YOUR-FIREBASE-APP>.firebaseio.com");
  return $firebaseArray(messagesRef);
})


.config(function($stateProvider, $urlRouterProvider) {
 
  $stateProvider
  .state('login', {
    url: '/',
    templateUrl: 'templates/login.html',
    controller: 'LoginCtrl'
  })
  .state('signup', {
    url: '/signup',
    templateUrl: 'templates/signup.html',
    controller: 'LoginCtrl'
  })  
  .state('signin', {
    url: '/signin',
    templateUrl: 'templates/signin.html',
    controller: 'LoginCtrl'
  });
 
  $urlRouterProvider.otherwise("/");
 
})


.controller('LoginCtrl', function($scope, $state) {
$state.go('chat');

$scope.signupEmail = function(){  
 
  var ref = new Firebase("https://<YOUR-FIREBASE-APP>.firebaseio.com");
 
  ref.createUser({
    email    : $scope.data.email,
    password : $scope.data.password
  }, function(error, userData) {
    if (error) {
      console.log("Error creating user:", error);
    } else {
      console.log("Successfully created user account with uid:", userData.uid);
    }
  });
 
};

  
$scope.loginEmail = function(){
 
  var ref = new Firebase("https://<YOUR-FIREBASE-APP>.firebaseio.com");
 
  ref.authWithPassword({
    email    : $scope.data.email,
    password : $scope.data.password
  }, function(error, authData) {
    if (error) {
      console.log("Login Failed!", error);
    } else {
      console.log("Authenticated successfully with payload:", authData);
    }
  });
 
};

}

 
.controller('ChatCtrl', function($scope, $state, $ionicPopup, Messages) {
 
  $scope.messages = Messages;
 
  $scope.addMessage = function() {
 
   $ionicPopup.prompt({
     title: 'Need to get something off your chest?',
     template: 'Let everybody know!'
   }).then(function(res) {
      $scope.messages.$add({
        "message": res
      });
   });
  };
 
  $scope.logout = function() {
    var ref = new Firebase("https://<YOUR-FIREBASE-APP>.firebaseio.com");
    ref.unauth();
    $state.go('login');
  };
 
})


.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if(window.cordova && window.cordova.plugins.Keyboard) {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

      // Don't remove this line unless you know what you are doing. It stops the viewport
      // from snapping when text inputs are focused. Ionic handles this internally for
      // a much nicer keyboard experience.
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})

